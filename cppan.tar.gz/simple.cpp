// simple.cpp - written and placed in the public domain by Wei Dai

#include "pch.h"

#ifndef CRYPTOPP_IMPORTS

#include "simple.h"

NAMESPACE_BEGIN(CryptoPP)

NAMESPACE_END

#endif
